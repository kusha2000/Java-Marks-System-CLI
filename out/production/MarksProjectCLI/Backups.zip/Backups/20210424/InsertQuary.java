import java.sql.*;
import java.util.Scanner;
public class InsertQuary{
	public static void insert(){
		Scanner sc=new Scanner(System.in);
		Data data=new Data();
		System.out.print("Enter Your name:");
		data.setname(sc.nextLine());
		System.out.print("Enter Your index number:");
		data.setindex(sc.nextInt());
		System.out.print("Enter Your t_marks:");
		data.sett_marks(sc.nextInt());
		System.out.print("Enter Your p_marks:");
		data.setp_marks(sc.nextInt());
		System.out.println(data.getname());
		System.out.println(data.getindex());
		System.out.println(data.gett_marks());
		System.out.println(data.getp_marks());
		try{
			Class.forName("com.mysql.jdbc.Driver");
			//System.out.println("Connectivity is OK...");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdata","root","");
			//System.out.println("MYSQL connection is OK...");
            Statement stat=con.createStatement();
            int i=stat.executeUpdate("INSERT INTO marks VALUES('"+data.getindex()+"','"+data.getname()+"','"+data.gett_marks()+"','"+data.getp_marks()+"')");
	    	System.out.println("The record inserted successfully.");
            System.out.println(i);
	    	con.close();
		}catch(Exception e){
			System.out.println("ERROR : "+e);
		}
	}
}
class Data{
	String name;
	int index;
	int t_marks;
	int p_marks;
	public void setname(String name){
		this.name=name;
	}
	public String getname(){
		return name;
	}
	public void setindex(int index){
		this.index=index;
	}
	public int getindex(){
		return index;
	}
	public void sett_marks(int t_marks){
		this.t_marks=t_marks;
	}
	public int gett_marks(){
		return t_marks;
	}
	public void setp_marks(int p_marks){
		this.p_marks=p_marks;
	}
	public int getp_marks(){
		return p_marks;
	}

}
