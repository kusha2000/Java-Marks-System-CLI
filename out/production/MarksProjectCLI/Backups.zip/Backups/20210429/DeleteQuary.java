import java.sql.*;
import java.util.Scanner;
public class DeleteQuary{
	public static void delete(){
		try{
			Scanner sc=new Scanner(System.in);
			System.out.print("Enter index number to need delete:");
			int inde=sc.nextInt();
			String conf;
			while(true){//while3
				System.out.print("Are You Sure(Y/N):");
				conf=sc.next();
				if(conf.equals("y")||conf.equals("Y")||conf.equals("n")||conf.equals("N")){
					break;	
				}else{
					System.out.println("Please press Y/N only");
				}
			}//end of while3
			if(conf.equals("y")||conf.equals("Y")){
					Class.forName("com.mysql.jdbc.Driver");
					//System.out.println("Connectivity is OK...");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdata","root","");
					//System.out.println("MYSQL connection is OK...");
		            Statement stat=con.createStatement();
		            int i=stat.executeUpdate("DELETE FROM marks WHERE st_index='"+inde+"'");
			    	System.out.println("The record deleted successfully.");
			    	con.close();
			}	
		}catch(Exception e){
			System.out.println("ERROR : "+e);
		}
	}
}
